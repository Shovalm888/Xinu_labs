/* clkint.c - clkint */

#include <conf.h>
#include <kernel.h>
#include <sleep.h>
#include <io.h>
#include "lab6_h.h"

/*------------------------------------------------------------------------
 *  clkint  --  clock service routine
 *  called at every clock tick and when starting the deferred clock
 *------------------------------------------------------------------------
 */
INTPROC clkint(mdevno)
int mdevno;				/* minor device number		*/
{
	int	i;
        int resched_flag;

        
	tod++;

    if (slp_empty)
        if ((-- * slp_top) <= 0)
            wakeupmem();
        

        resched_flag = 0;
	if (slnempty)
		if ( (--*sltop) <= 0 )
         {
            resched_flag = 1;
			wakeup();
         } /* if */
	if ( (--preempt) <= 0 )
             resched_flag = 1;

       if (resched_flag == 1)
 		resched();

}

